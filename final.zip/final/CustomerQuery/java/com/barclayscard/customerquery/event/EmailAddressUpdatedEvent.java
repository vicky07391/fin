package com.barclayscard.customerquery.event;

public class EmailAddressUpdatedEvent extends AbstractEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String emailAddress;

	public EmailAddressUpdatedEvent(String id, String emailAddress) {
		super(id);
		this.emailAddress = emailAddress;
	}

	

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	
}
