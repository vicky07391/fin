package com.barclayscard.customerquery.repository;



import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import com.barclayscard.customerquery.domain.Customer;


@RepositoryRestResource(collectionResourceRel = "customers", path = "customers")
public interface CustomerRepository extends MongoRepository<Customer , String>{
	public Customer findById(@Param("Id") String Id);

	@SuppressWarnings("unchecked")
	public Customer save(Customer customer);

}
