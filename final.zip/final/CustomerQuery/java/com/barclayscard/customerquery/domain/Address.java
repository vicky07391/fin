package com.barclayscard.customerquery.domain;

public class Address {

	private  final String buildingName;

	private  final String streetName;

	private final String pincode;



	public Address(String buildingName, String streetName, String pincode) {
		this.buildingName = buildingName;
		this.streetName = streetName;
		this.pincode = pincode;
	}


	/**
	 * @return the buildingName
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", streetName=" + streetName + ", pincode=" + pincode + "]";
	}

}
