package com.barclayscard.customerquery;


import java.io.Serializable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class JMSManager
{
	//String DEFAULT_BROKER_URL="tcp://localhost:61616";
	//@Autowired
	//ActiveMQConnectionFactory activeMQConnectionFactory;
    public void sendMessage(final Serializable message, final String queueName) throws Exception
    {
       ConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(ActiveMQConnection.DEFAULT_BROKER_URL);
        Connection connection = activeMQConnectionFactory.createConnection();    
        Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE); 
        Queue queue = session.createQueue("example-queue");
        MessageProducer producer = session.createProducer(queue);
         
        connection.start();
         
        ObjectMessage m1 = session.createObjectMessage();   
        m1.setObject(message);
         
        producer.send(m1);
         
        connection.close();
    }
}