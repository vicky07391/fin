package com.barclayscard.customer.events;

import java.io.Serializable;

/**
 * AbstractEvent is for unique event id.
 */
public abstract class AbstractEvent implements Serializable {
	private static final long serialVersionUID = 1L;
	/** Unique identifier for events. */
	private String id;

	 /** Source identifier for event. */
	 private String sourceIdentifier = "RABBITMQ TCP";

	/** No Argument Constructor. */
	public AbstractEvent() {
	}

	/**
	 * Argument Constructor.
	 * @param id identifier
	 */
	public AbstractEvent(String id) {
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 *  Getter for SourceIdentifier.
	 * @return sourceIdentifier
	 */
	  public String getSourceIdentifier() {
		  return sourceIdentifier;
	  }

}
