package com.barclayscard.customerquery.domain.customer.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.barclayscard.customerquery.domain.customer.Customer;
import com.barclayscard.customerquery.domain.customer.repository.CustomerRepository;

/*import com.barclayscard.customerquery.domain.customer.Customer;
import com.barclayscard.customerquery.domain.customer.repository.CustomerRepository;*/

/*import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;*/

/**
 * CustomerRestController is act as a Rest Controller for querying the customer
 * data.
 */
@RestController
@RequestMapping("/customers")
public class CustomerRestController {
	/** @Autowired the Customer Repository. */
	@Autowired
	private CustomerRepository customerRepository;

/**
 * @ApiResponses : Swagger API responses with message.
 */
/*	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK,
			message = "Successfully retrieved list"),
			@ApiResponse(code = HttpServletResponse.SC_CREATED, message = "Customer successfully created"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
			message = "You are not authorized to view the resource"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
			message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND,
			message = "The resource you were trying to reach is not found") })

	@ApiOperation(value = "Search a customer with an ID", response = Customer.class)*/
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Customer customerFind(@PathVariable(value = "id") String id, 
		HttpServletResponse response) {
		Customer customer = customerRepository.findById(id);
		if (customer != null) {
			response.setStatus(HttpServletResponse.SC_OK);
		} else {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);

		}
		return customer;
	}
}
