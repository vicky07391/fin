package com.barclayscard.customer.valueobjects;

import java.io.Serializable;

/**
 * This class is treated as an value object for customer aggregate root.
 *
 */
public class Address implements Serializable {
	private static final long serialVersionUID = 1L;
	/** Building name of address of customer. */
	private String buildingName;
	/** Street name of address of customer. */
	private String streetName;
	/** Pin code of address of customer. */
	private String pincode;

	/** No Argument Constructor. */
	public Address() {
	}

	/**
	 * Argument Constructor.
	 * @param buildingName
	 *            Building Name
	 * @param streetName
	 *            Street Name
	 * @param pincode
	 *            Pin Code
	 */
	public Address(String buildingName, String streetName, String pincode) {
		super();
		this.buildingName = buildingName;
		this.streetName = streetName;
		this.pincode = pincode;
	}

	/**
	 * @return the buildingName
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}
	/**
	 * .
	 */
	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", streetName=" + streetName
				+ ", pincode=" + pincode + "]";
	}

}
