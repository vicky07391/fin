package com.barclayscard.customerquery.domain.customer.handler;

import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.barclayscard.customer.events.AddressUpdatedEvent;
import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.events.EmailAddressUpdatedEvent;
import com.barclayscard.customer.events.MobileNumberUpdatedEvent;
import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customerquery.domain.customer.Customer;
import com.barclayscard.customerquery.domain.customer.repository.CustomerRepository;

/**
 * CustomerViewEventHandler is act as a event listener and stores the customer data into database.
 */
//@Component
public class CustomerViewEventHandler {
	/**Logger initialization for CustomerViewEventHandler.*/
	private static final Logger LOG = LoggerFactory.getLogger(CustomerViewEventHandler.class);
	/** @Autowired the Customer Repository. */
	@Autowired(required= true)
	public CustomerRepository repository;

	/**
	 * handler method for CustomerAddedEvent.
	 * @param event
	 *            CustomerAddedEvent
	 */
	@EventHandler
	public void handle(CustomerAddedEvent event) {
		if(repository == null){
			System.out.println("========REPOSITORY NULL===");
		}
		LOG.info("============CustomerAddedEvent: [{}] '{}'", event.getId(), event.getFirstName());
		Customer customer = new Customer();
		Address address = new Address(event.getAddress().getBuildingName(), event.getAddress().getStreetName(),
				event.getAddress().getPincode());
		customer.setId(event.getId());
		customer.setFirstName(event.getFirstName());
		customer.setLastName(event.getLastName());
		customer.setDob(event.getDob());
		customer.setEmailAddress(event.getEmailAddress());
		customer.setMobileNumber(event.getMobileNumber());
		customer.setAddress(address);
		repository.save(customer);
	}

	/**
	 * handler method for CustomerAddedEvent.
	 * @param event
	 *            AddressUpdatedEvent
	 */
	@EventHandler
	public void handle(AddressUpdatedEvent event) {
//		LOG.info("AddressUpdatedEvent: [{}] '{}'", event.getId(), event.getAddress());
		/*Customer customer = repository.findById(event.getId());
		if (customer.getId() != null && !(customer.getAddress().equals(event.getAddress()))) {
			customer.setAddress(event.getAddress());
//			repository.save(customer);
		}*/

	}

	/**
	 * handler method for CustomerAddedEvent.
	 * @param event
	 *            EmailAddressUpdatedEvent
	 */
	@EventHandler
	public void handle(EmailAddressUpdatedEvent event) {
//		LOG.info("EmailAddressUpdatedEvent: [{}] '{}'", event.getId(), event.getEmailAddress());
		/*Customer customer = repository.findById(event.getId());
		if (customer != null) {
			customer.setEmailAddress(event.getEmailAddress());
//			repository.save(customer);
		}*/

	}

	/**
	 * handler method for CustomerAddedEvent.
	 * @param event
	 *            MobileNumberUpdatedEvent
	 */
	@EventHandler
	public void handle(MobileNumberUpdatedEvent event) {
//		LOG.info("MobileNumberUpdatedEvent: [{}] '{}'", event.getId(), event.getMobileNumber());
		/*Customer customer = repository.findById(event.getId());
		if (customer.getId() != null && !(customer.getMobileNumber().equals(event.getMobileNumber()))) {
			customer.setMobileNumber(event.getMobileNumber());
//			repository.save(customer);
		}*/

	}

}