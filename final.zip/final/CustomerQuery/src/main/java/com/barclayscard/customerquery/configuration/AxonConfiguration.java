package com.barclayscard.customerquery.configuration;

import static com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory.from;

import java.util.Map;
import java.util.Properties;

import org.axonframework.contextsupport.spring.AnnotationDriven;
import org.axonframework.domain.EventMessage;
import org.axonframework.eventhandling.Cluster;
import org.axonframework.eventhandling.ClusteringEventBus;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.EventBusTerminal;
import org.axonframework.eventhandling.SimpleCluster;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerAdapter;
import org.axonframework.eventhandling.annotation.EventHandler;
//import org.axonframework.serializer.json.JacksonSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.barclayscard.customerquery.domain.customer.handler.CustomerViewEventHandler;
import com.codahale.metrics.MetricRegistry;
import com.google.common.collect.ImmutableMap;
import com.mongodb.MongoClient;
//import com.mongodb.MongoClient;
import com.viadeo.axonframework.eventhandling.cluster.ClassnameDynamicClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.ConsumerFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaMetricHelper;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.PrefixTopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategyFactory;

import kafka.consumer.ConsumerConfig;

/**
 * Axon Configuration for CQRS Application.
 *
 */
@Configuration
@AnnotationDriven
@ComponentScan("com.barclayscard")
public class AxonConfiguration {
	private static final String PREFIX = "com.barclayscard";

	/** amqp config key for queue. */
//	private static final String KAFKA_CONFIG_KEY = "Kafka.Config";


/*
	/** MongoDB Host name. */
	@Value("${spring.data.mongodb.host}")
	private String host;
	/** MongoDB Database name. */
	@Value("${spring.data.mongodb.database}")
	private String mongoDB;

	/**
	 * Serializer implementation that uses Jackson to serialize objects into a
	 * JSON format.
	 * @return JacksonSerializer.
	 */

	/**
	 * Manages the lifecycle of the SimpleMessageListenerContainers that have
	 * been created to receive messages for Clusters. The
	 * ListenerContainerLifecycleManager starts each of the Listener Containers
	 * when the context is started and will stop each of them when the context
	 * is being shut down.
	 * @return ListenerContainerLifecycleManager
	 */

	@Bean
	ConsumerConfig consumerConfig() {

		Properties props = new Properties();
		props.put("zookeeper.connect", "localhost:2181");
		props.put("group.id", "testgroup");
		props.put("zookeeper.session.timeout.ms", "400");
		props.put("zookeeper.sync.time.ms", "300");
		props.put("auto.commit.interval.ms", "1000");

		return new ConsumerConfig(props);

	}
	
	@Bean
	public ConsumerFactory consumerFactory() {
		return new ConsumerFactory(consumerConfig());
	}
	

	@Bean
	public MetricRegistry metricRegistry() {

		return new MetricRegistry();
	}

	@Bean
	public KafkaMetricHelper kafkaMetricHelper() {

		return new KafkaMetricHelper(metricRegistry(), PREFIX);
	}

	public static final ImmutableMap<String, String> KAFKA_PROPERTIES_MAP = ImmutableMap.<String, String>builder()
			// PRODUCER
			.put("metadata.broker.list", "localhost:9092").put("request.required.acks", "1")
			.put("producer.type", "sync")

			// CONSUMER
			.put("zookeeper.connect", "localhost:2181")
			// this property will be overridden by the cluster
			.put("group.id", "testgroup")
			// !important; without the following property then this suite is
			// unstable (due to the process of the auto creation topic)
			.put("auto.offset.reset", "smallest")

			.put("zookeeper.session.timeout.ms", "400").put("zookeeper.sync.time.ms", "300")
			.put("auto.commit.interval.ms", "1000").build();

	@Bean
	public SimpleCluster simpleCluster() {

		SimpleCluster cluster = new SimpleCluster("TestTopic");
		return cluster;
	}
	


	public static ClusterSelectorFactory createClusterSelectorFactory(final String prefix) throws Exception{
		return new ClassnameDynamicClusterSelectorFactory(prefix, new ClusterFactory() {
			@Override
			public Cluster create(final String name) {
				return new SimpleCluster(name);
			}
		});
	}

	

	
	public KafkaTerminalFactory kafkaTerminalFactory(final Map<String, String> properties) {

		return new KafkaTerminalFactory(from(properties));
	}
	

	
	@Bean
	public TopicStrategyFactory topicStrategyFactory() {

		TopicStrategyFactory currentTopicStrategyFactory = new TopicStrategyFactory() {
			@Override
			public TopicStrategy create() {
				final String prefix = "";

				kafkaTerminalFactory(KAFKA_PROPERTIES_MAP)
						.setConsumerProperty(ConsumerFactory.CONSUMER_TOPIC_FILTER_REGEX, prefix + ".*");

				return new PrefixTopicStrategy(prefix);
			}
		};

		return currentTopicStrategyFactory;
	}
	
	@Bean
	public TopicStrategy topicStrategy() {

		TopicStrategy currentTopicStrategy = topicStrategyFactory().create();

		return currentTopicStrategy;
	}
	
	

	
	@Bean
	public EventBusTerminal eventBusTerminal() {

		EventBusTerminal currentTerminal = kafkaTerminalFactory(KAFKA_PROPERTIES_MAP).with(topicStrategy()).create();

		return currentTerminal;
	}
	
	
	@Bean
	public EventBus eventBus() throws Exception {

		EventBus currentEventBus = new ClusteringEventBus(createClusterSelectorFactory(PREFIX).create(),
				eventBusTerminal());
//		currentEventBus.subscribe(new AnnotationEventListenerAdapter(new CustomerViewEventHandler(), null));
		currentEventBus.subscribe(new AnnotationEventListenerAdapter(customerViewEventHandler()));
		return currentEventBus;
	}

	private static class ThreadPrintingEventListener {

		@EventHandler
		public void onEvent(EventMessage event) {
			System.out.println("===========Received query====================== " + event.getPayload().toString() + " on thread named "
					+ Thread.currentThread().getName());
		}
	}


	/**
	 * The MongoTemplate is the mechanism that connects to MongoDB.
	 * @return MongoTemplate
	 * @throws Exception exception
	 */
	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(new MongoClient(host), mongoDB);
	}

	/**
	 * CustomerViewEventHandler bean creation.
	 * @return customerViewEventHandler
	 */
	@Bean
	public CustomerViewEventHandler customerViewEventHandler() {
		CustomerViewEventHandler customerViewEventHandler = new CustomerViewEventHandler();
		return customerViewEventHandler;
	}

	
	/* public @Bean
      MongoDbFactory mongoDbFactory() throws Exception{
          return new SimpleMongoDbFactory(new MongoClient(host), mongoDB);
      }

      public @Bean
      MongoTemplate mongoTemplate() throws Exception{
          MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
          return mongoTemplate;
      }*/
	/**
	 * CustomerViewEventHandler bean creation.
	 * @return customerViewEventHandler
	 */
	/*@Bean
	public CustomerViewEventHandler customerViewEventHandler() {
		CustomerViewEventHandler customerViewEventHandler = new CustomerViewEventHandler();
		return customerViewEventHandler;
	}*/

	
}
