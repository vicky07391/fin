package com.barclayscard.customerquery.domain.customer;

import java.util.Date;

import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Document;

import com.barclayscard.customer.valueobjects.Address;

/**
 * Customer is act as an Document for database of Customer.
 */
@Document(collection = "customer")
public class Customer {
	/** id of customer. */
	
	/** No Argument Constructor. */
	public Customer() {
	}
	@Id
	private String id;
	/** First Name of customer. */
	private String firstName;
	/** Last Name of customer. */
	private String lastName;
	/** Mobile Number of customer. */
	private String mobileNumber;
	/** Email of customer. */
	private String emailAddress;
	/** Address{Building Name, Street Name, Pin code} of customer. */
	private Address address;
	/** Date of Birth of customer. */
	private Date dob;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber
	 *            the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	

	/**
	 * Argument Constructor.
	 * @param firstName
	 *            First Name of customer
	 * @param lastName
	 *            Last Name of customer
	 * @param mobileNumber
	 *            Mobile Number of customer
	 * @param emailAddress
	 *            Email of customer
	 * @param address
	 *            Address{Building Name, Street Name, Pin code} of customer
	 * @param dob
	 *            Date of Birth of customer
	 */
	public Customer(String firstName, String lastName, String mobileNumber, String emailAddress, Address address,
			Date dob) {
//		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		this.dob = dob;
	}

	/** toString method for representation of customer object . */
	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNumber=" + mobileNumber + ", emailAddress="
				+ emailAddress + ", address=" + address + ", dob=" + dob + "]";
	}

	/** hashCode method for generating the hash code of customer object . */
	@Override
	public int hashCode() {
		int f = 0;
		final int prime = 31;
		int result = 1;
		if (id == null) {
			f = 0;
		} else {
			f = id.hashCode();
		}
		result = prime * result + f;
		return result;
	}

	/* hashCode method for generating the hash code of customer object . */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
			}
		if (obj == null) {
			return false;
			}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Customer other = (Customer) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
