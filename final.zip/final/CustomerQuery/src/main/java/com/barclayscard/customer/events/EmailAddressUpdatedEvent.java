package com.barclayscard.customer.events;
/**
 * EmailAddressUpdatedEvent is an event class for Email updating of customer.
 */
public class EmailAddressUpdatedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;
	/**
	 * Email field of customer.
	 */
	private String emailAddress;
	/** No Argument Constructor. */
	public EmailAddressUpdatedEvent() {
	}
	/**
	 * Argument Constructor.
	 * @param id
	 *            identifier
	 * @param emailAddress
	 *            email
	 */
	public EmailAddressUpdatedEvent(String id, String emailAddress) {
		super(id);
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

}
