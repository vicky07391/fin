package com.barclayscard.customercommand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*import static com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory.from;

import java.util.Map;

import org.axonframework.eventhandling.Cluster;
import org.axonframework.eventhandling.SimpleCluster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viadeo.axonframework.eventhandling.cluster.ClassnameDynamicClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory;
import static com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory.from;
import static org.axonframework.domain.GenericEventMessage.asEventMessage;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.axonframework.domain.EventMessage;
import org.axonframework.domain.GenericEventMessage;
import org.axonframework.eventhandling.Cluster;
import org.axonframework.eventhandling.ClusteringEventBus;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.EventBusTerminal;
import org.axonframework.eventhandling.SimpleCluster;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerAdapter;
import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.codahale.metrics.MetricRegistry;
import com.google.common.collect.ImmutableMap;
import com.viadeo.axonframework.eventhandling.cluster.ClusterFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.ConsumerFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaClusterListener;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaMetricHelper;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.PrefixTopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategyFactory;

import kafka.consumer.ConsumerConfig;*/

/** Spring Boot Application class. */
@SpringBootApplication
public class CommandSideMicroserviceApplication {

  /**
   * Application Main Method.
   * @param args argument
   */
/*	private static Logger log = LoggerFactory.getLogger(CommandSideMicroserviceApplication.class);

	//providing implementation for create method of ClusterFactory interface.
	public static final ClusterFactory CLUSTER_FACTORY = new ClusterFactory() {
		@Override

		public Cluster create(String name) {
			return new SimpleCluster(name);
		}
	};

	//KafkaTerminalFactory implements EventBusTerminalFactory interface 
	//usage to create eventBusTerminal 
	public static KafkaTerminalFactory createKafkaTerminalFactory(final Map<String, String> properties) {
		return new KafkaTerminalFactory(from(properties));
	}

	private static final String PREFIX = "Barclaycard.cluster";

	//Setting Kafka producer and consumer properties
	public static final ImmutableMap<String, String> KAFKA_PROPERTIES_MAP = ImmutableMap.<String, String>builder()
			// PRODUCER
			.put("metadata.broker.list", "localhost:9092").put("request.required.acks", "1")
			.put("producer.type", "sync")
			// .put("serializer.class", "kafka.serializer.DefaultEncoder")
			// CONSUMER
			.put("zookeeper.connect", "localhost:2181")
			// this property will be overridden by the cluster
			.put("group.id", "testgroup")
			// !important; without the following property then this suite is
			// unstable (due to the process of the auto creation topic)
			.put("auto.offset.reset", "smallest")

			.put("zookeeper.session.timeout.ms", "400").put("zookeeper.sync.time.ms", "300")
			.put("auto.commit.interval.ms", "1000").build();

	public static class CustomEventMessage extends GenericEventMessage<String> {

		public CustomEventMessage(String payload) {
			super(payload);
		}
	}
	public static ClusterSelectorFactory createClusterSelectorFactory(final String prefix) {
		return new ClassnameDynamicClusterSelectorFactory(prefix, new ClusterFactory() {
			@Override
			public Cluster create(final String name) {
				return new SimpleCluster(name);
			}
		});
	}
*/

	public static void main(String[] args) {
		SpringApplication.run(CommandSideMicroserviceApplication.class, args);
		/*final KafkaTerminalFactory terminalFactory = createKafkaTerminalFactory(KAFKA_PROPERTIES_MAP);

		TopicStrategyFactory currentTopicStrategyFactory = new TopicStrategyFactory() {
			@Override
			public TopicStrategy create() {
				final String prefix = UUID.randomUUID().toString();

				// set the generated prefix as property, TODO found a better way
				// in order to pass this restriction to our consumer
				terminalFactory.setConsumerProperty(ConsumerFactory.CONSUMER_TOPIC_FILTER_REGEX, prefix + ".*");

				return new PrefixTopicStrategy(prefix);
			}
		};
		TopicStrategy currentTopicStrategy = currentTopicStrategyFactory.create();
		EventBusTerminal currentTerminal = terminalFactory.with(currentTopicStrategy).create();
		final String zkConnect = "localhost:2181";

		Properties props = new Properties();
		props.put("zookeeper.connect", "localhost:2181");
		props.put("group.id", "testgroup");
		props.put("zookeeper.session.timeout.ms", "400");
		props.put("zookeeper.sync.time.ms", "300");
		props.put("auto.commit.interval.ms", "1000");
		ConsumerConfig consumerConfig = new ConsumerConfig(props);
		ConsumerFactory consumerFactory = new ConsumerFactory(consumerConfig);
		MetricRegistry metricRegistry = new MetricRegistry();
		KafkaMetricHelper kafkaMetricHelper = new KafkaMetricHelper(metricRegistry, PREFIX);

		EventBus currentEventBus = new ClusteringEventBus(createClusterSelectorFactory(PREFIX).create(),
				currentTerminal);
		
		currentEventBus.subscribe(new AnnotationEventListenerAdapter(new ThreadPrintingEventListener()));

		currentEventBus.publish(asEventMessage(
				new CargoTrackingCommandMessage("START1", "testCargoId1", "testCorrelationId1", "someTimestamp1")
						.toString()));*/
	
	}
	/*
	private static class ThreadPrintingEventListener {

		@EventHandler
		public void onEvent(EventMessage event) {
			System.out.println("Received " + event.getPayload().toString() + " on thread named "
					+ Thread.currentThread().getName());
		}
	}*/
}
