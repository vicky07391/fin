package com.barclayscard.customercommand.aggregate.commands;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;
import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

import com.barclayscard.customer.valueobjects.Address;


/**
 * command class for creation of customer.
 */
public class AddCustomerCommand implements Serializable {

  private static final long serialVersionUID = 1L;

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final String id;

  /** First Name of Customer. */
  @NotNull(message = "First Name is mandatory")
  @NotBlank
  private final String firstName;

  /** Last Name of Customer. */
  @NotNull(message = "Last Name is mandatory")
  @NotBlank
  private final String lastName;

  /** Mobile Number of Customer. */
  @NotNull(message = "MobileNumber is mandatory")
  @NotBlank
  private final String mobileNumber;

  /** Email Address of Customer. */
  @NotNull(message = "EmailAddress is mandatory")
  @NotBlank
  private final String emailAddress;

  /** Address of Customer. */
  @NotNull
  private final Address address;

  /** Date of Birth of Customer. */
  @NotNull(message = "DOB is mandatory")
  private final Date dob;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier.
   * @param firstName
   *          First Name
   * @param lastName
   *          Last Name
   * @param mobileNumber
   *          Mobile Number.
   * @param emailAddress
   *          Email Address.
   * @param address
   *          Address.
   * @param dob
   *          Date of Birth.
   */
  public AddCustomerCommand(String id, String firstName, String lastName, String mobileNumber,
      String emailAddress, Address address, Date dob) {
    super();
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.mobileNumber = mobileNumber;
    this.emailAddress = emailAddress;
    this.address = address;
    this.dob = dob;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @return the firstName
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * @return the lastName
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

  /**
   * @return the address
   */
  public Address getAddress() {
    return address;
  }

  /**
   * @return the dob
   */
  public Date getDob() {
    return dob;
  }

}
