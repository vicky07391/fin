package com.barclayscard.customer.events;

import java.util.Date;
import com.barclayscard.customer.valueobjects.Address;



/**
 * . This is the event class for creation of customer
 */
public class CustomerAddedEvent extends AbstractEvent {

  private static final long serialVersionUID = 1L;
  /** First name. */
  private String firstName;

  /** Last name. */
  private String lastName;

  /** Mobile Number. */
  private String mobileNumber;

  /** Email Address. */
  private String emailAddress;

  /** Address (Building name, street name, pin code ) . */
  private Address address;

  /** Date of Birth. */
  private Date dob;

  /**
   * No argument constructor.
   */
  public CustomerAddedEvent() {
  }

  /**
   * Constructor with arguments.
   * @param id
   *          identifier
   * @param firstName
   *          first Name of customer
   * @param lastName
   *          last Name of customer
   * @param mobileNumber
   *          mobile no
   * @param emailAddress
   *          email
   * @param address
   *          address
   * @param dob
   *          date of birth
   */
  public CustomerAddedEvent(String id, String firstName, String lastName, String mobileNumber,
      String emailAddress, Address address, Date dob) {
    super(id);
    this.firstName = firstName;
    this.lastName = lastName;
    this.mobileNumber = mobileNumber;
    this.emailAddress = emailAddress;
    this.address = address;
    this.dob = dob;
  }

  /**
   * @return the firstName
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * @return the lastName
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * @return the mobileNumber
   */

  public String getMobileNumber() {
    return mobileNumber;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

  /**
   * @return the address
   */
  public Address getAddress() {
    return address;
  }

  /**
   * @return the dob
   */
  public Date getDob() {
    return dob;
  }
}
