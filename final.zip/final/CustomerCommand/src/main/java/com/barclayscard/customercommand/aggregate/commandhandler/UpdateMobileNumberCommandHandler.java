package com.barclayscard.customercommand.aggregate.commandhandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.barclayscard.customercommand.aggregate.CustomerAggregate;
import com.barclayscard.customercommand.aggregate.commands.UpdateMobileNumberCommand;

/** Command Handler for Updating Mobile Number. */
@Component
public class UpdateMobileNumberCommandHandler {

  /** Auto wired EventSourceRepository. */
  @Autowired
  private EventSourcingRepository<CustomerAggregate> customerEventSourcingRepository;

  /** Create LoggerFactory for UpdateAddressCommandHandler. */
  private static final Logger LOG = LoggerFactory.getLogger(UpdateMobileNumberCommandHandler.class);

  /**
   * Method for UpdateMobileNumberCommand Handler.
   * @param command
   *          UpdateMobileNumberCommand.
   */
  @CommandHandler
  public void updateMobileNumber(UpdateMobileNumberCommand command) {
    LOG.info("Command: 'UpdateMobileNumberCommand' received.");
    CustomerAggregate customerAggregate = (CustomerAggregate) customerEventSourcingRepository
        .load(command.getId());
    customerAggregate.updateMobileNumber(command.getMobileNumber());
  }

}
