package com.barclayscard.customercommand.validation;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

/**
 * mobileNumber request parameter with validation annotation.
 * @author Capgemini
 *
 */
public class MobileNumberRequest {

	/**
	 * mobileNumber validation {Not Null , NotBlank}.
	 */
	@NotNull
	@NotBlank
	private String mobileNumber;

	/**
	 * Return mobile Number.
	 * @return mobileNumber.
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * set the value for mobile number.
	 * @param mobileNumber mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}
