package com.barclayscard.customercommand.configuration;

import static com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory.from;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import org.axonframework.auditing.AuditLogger;
import org.axonframework.auditing.AuditingInterceptor;
import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.annotation.AggregateAnnotationCommandHandler;
import org.axonframework.commandhandling.annotation.AnnotationCommandHandlerBeanPostProcessor;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.gateway.CommandGatewayFactoryBean;
import org.axonframework.commandhandling.gateway.IntervalRetryScheduler;
import org.axonframework.commandhandling.gateway.RetryScheduler;
import org.axonframework.commandhandling.interceptors.BeanValidationInterceptor;
import org.axonframework.contextsupport.spring.AnnotationDriven;
import org.axonframework.domain.EventMessage;
import org.axonframework.eventhandling.Cluster;
import org.axonframework.eventhandling.ClusteringEventBus;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.EventBusTerminal;
import org.axonframework.eventhandling.SimpleCluster;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerBeanPostProcessor;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventstore.EventStore;
import org.axonframework.eventstore.mongo.DefaultMongoTemplate;
import org.axonframework.eventstore.mongo.MongoEventStore;
import org.axonframework.eventstore.mongo.MongoTemplate;
import org.axonframework.serializer.json.JacksonSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.barclayscard.customercommand.aggregate.CustomerAggregate;
import com.barclayscard.customercommand.service.CommandService;
import com.barclayscard.customercommand.service.CommandServiceImpl;
import com.codahale.metrics.MetricRegistry;
import com.google.common.collect.ImmutableMap;
import com.mongodb.DuplicateKeyException;
import com.mongodb.Mongo;
import com.viadeo.axonframework.eventhandling.cluster.ClassnameDynamicClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterFactory;
import com.viadeo.axonframework.eventhandling.cluster.ClusterSelectorFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.ConsumerFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaMetricHelper;
import com.viadeo.axonframework.eventhandling.terminal.kafka.KafkaTerminalFactory;
import com.viadeo.axonframework.eventhandling.terminal.kafka.PrefixTopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategy;
import com.viadeo.axonframework.eventhandling.terminal.kafka.TopicStrategyFactory;

import kafka.api.TopicData;
import kafka.producer.ProducerConfig;

/**
 * Axon Configuration for CQRS Application.
 *
 */
@Configuration
@AnnotationDriven
@ComponentScan("com.barclayscard")
public class AxonConfiguration {

	private static final String PREFIX = "barclayscard";

	/** IntervalRetryScheduler interval count. */
	@Value("${spring.retryschedular.interval}")
	private int interval;

	/** IntervalRetryScheduler retry count. */
	@Value("${spring.retryschedular.count}")
	private int retryCount;

	/**
	 * that can schedule commands to run after a given delay, or to execute
	 * periodically.
	 */
	private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

	/** auto wire the bean of mongo. */
	@Autowired
	private Mongo mongo;


	/**
	 * The actual value expression of mongo database name :
	 * {applicationProperties.mongodb.dbname.
	 */
	@Value("${mongodb.dbname}")
	private String mongoDbName;

	/**
	 * The actual value expression of event collection name :
	 * {applicationProperties.mongodb.events.collection.name.
	 */
	@Value("${mongodb.events.collection.name}")
	private String eventsCollectionName;

	/**
	 * The actual value expression of events snapshot collection.name :
	 * {applicationProperties.mongodb.events.snapshot.collection.name.
	 */
	@Value("${mongodb.events.snapshot.collection.name}")
	private String snapshotCollectionName;

	/**
	 * Serializer implementation that uses Jackson to serialize objects into a
	 * JSON format.
	 * 
	 * @return JacksonSerializer.
	 */
	@Bean
	JacksonSerializer axonJsonSerializer() {
		return new JacksonSerializer();
	}

	@Bean
	MetricRegistry metricRegistry() {
		return new MetricRegistry();
	}

	@Bean
	KafkaMetricHelper kafkaMetricHelper() {

		return new KafkaMetricHelper(metricRegistry(), PREFIX);
	}

	public static final ImmutableMap<String, String> KAFKA_PROPERTIES_MAP = ImmutableMap.<String, String>builder()
			// PRODUCER
			.put("metadata.broker.list", "localhost:9092").put("request.required.acks", "1")
			.put("producer.type", "sync")

			// CONSUMER
			.put("zookeeper.connect", "localhost:2181")
			// this property will be overridden by the cluster
			.put("group.id", "testgroup")
			// !important; without the following property then this suite is
			// unstable (due to the process of the auto creation topic)
			.put("auto.offset.reset", "smallest")

			.put("zookeeper.session.timeout.ms", "400").put("zookeeper.sync.time.ms", "300")
			.put("auto.commit.interval.ms", "1000").build();

	@Bean
	SimpleCluster simpleCluster() {
		SimpleCluster cluster = new SimpleCluster("TestTopic");
		return cluster;
	}
	

	@Bean
	ClusterSelectorFactory createClusterSelectorFactory(final String prefix) {
		return new ClassnameDynamicClusterSelectorFactory(prefix, new ClusterFactory() {
			@Override
			public Cluster create(final String name) {
				return new SimpleCluster(name);
			}
		});
	}

	

	@Bean
	KafkaTerminalFactory kafkaTerminalFactory(final Map<String, String> properties) {
		return new KafkaTerminalFactory(from(properties));
	}
	


	@Bean
	TopicStrategyFactory topicStrategyFactory() {

		TopicStrategyFactory currentTopicStrategyFactory = new TopicStrategyFactory() {
			@Override
			public TopicStrategy create() {
				final String prefix = "";

				kafkaTerminalFactory(KAFKA_PROPERTIES_MAP)
				.setConsumerProperty(ConsumerFactory.CONSUMER_TOPIC_FILTER_REGEX, prefix );

				return new PrefixTopicStrategy(prefix);
			}
		};

		return currentTopicStrategyFactory;
	}
	
	@Bean
	TopicStrategy topicStrategy() {

		TopicStrategy currentTopicStrategy = topicStrategyFactory().create();

		return currentTopicStrategy;
	}
	

	@Bean
	EventBusTerminal eventBusTerminal() {
		EventBusTerminal currentTerminal = kafkaTerminalFactory(KAFKA_PROPERTIES_MAP).with(topicStrategy()).create();
		return currentTerminal;
	}
	
	
	
	@Bean
	public EventBus eventBus() {
		System.out.println("======in EVENT BUS=======");
		EventBus currentEventBus = new ClusteringEventBus(createClusterSelectorFactory(PREFIX).create(),
				eventBusTerminal());
		return currentEventBus;
	}
	
	

	/**
	 * Constructor used for a basic template configuration.
	 * 
	 * @return MongoTemplate
	 */
	@Bean(name = "axonMongoTemplate")
	MongoTemplate axonMongoTemplate() {
		MongoTemplate template = new DefaultMongoTemplate(mongo, mongoDbName, eventsCollectionName,
				snapshotCollectionName, null, null);
		return template;
	}

	/**
	 * Abstraction of the event storage mechanism. Domain Events are stored and
	 * read as streams.
	 * @return EventStore
	 * @throws DuplicateKeyException
	 *             duplicateKeyException
	 */
	@Bean
	EventStore eventStore() {
		MongoEventStore eventStore = new MongoEventStore(axonJsonSerializer(), axonMongoTemplate());
		return eventStore;
	}
	

	/**
	 * Command Bus is the mechanism that dispatches commands to their respective
	 * Command Handler.
	 * @return CommandBus
	 */
	@Bean
	CommandBus commandBus() {
		SimpleCommandBus commandBus = new SimpleCommandBus();
		List list = new ArrayList();
		list.add(auditingInterceptor());
		list.add(new BeanValidationInterceptor());
		commandBus.setHandlerInterceptors(list);
		return commandBus;
	}

	/**
	 * AuditLogger bean.
	 * 
	 * @return logger
	 */
	@Bean
	AuditLogger myAuditLogger() {
		CustomerAuditLogger logger = new CustomerAuditLogger();
		return logger;
	}

	/**
	 * AuditingInterceptor bean.
	 * 
	 * @return auditingInterceptor
	 */
	@Bean
	AuditingInterceptor auditingInterceptor() {
		AuditingInterceptor i = new AuditingInterceptor();
		i.setAuditLogger(myAuditLogger());
		return i;
	}

	/**
	 * Spring Bean post processor that automatically generates an adapter for
	 * each bean containing EventHandler annotated methods.
	 * 
	 * @return AnnotationEventListenerBeanPostProcessor
	 */
	@Bean
	AnnotationEventListenerBeanPostProcessor eventListenerBeanPostProcessor() {
		AnnotationEventListenerBeanPostProcessor proc = new AnnotationEventListenerBeanPostProcessor();
		proc.setEventBus(eventBus());
		return proc;
	}

	/**
	 * This method allows Axon to automatically find your @CommandHandler's.
	 * 
	 * @return AnnotationCommandHandlerBeanPostProcessor
	 */

	@Bean
	AnnotationCommandHandlerBeanPostProcessor commandHandlerBeanPostProcessor() {
		AnnotationCommandHandlerBeanPostProcessor proc = new AnnotationCommandHandlerBeanPostProcessor();
		proc.setCommandBus(commandBus());
		return proc;
	}

	/**
	 * FactoryBean that creates a gateway instance for any given (compatible)
	 * interface. If no explicit interface is provided, the
	 * {@link CommandGateway} interface is assumed.
	 * 
	 * @return CommandGatewayFactoryBean
	 */
	@Bean
	CommandGatewayFactoryBean<CommandGateway> commandGatewayFactoryBean() {
		CommandGatewayFactoryBean<CommandGateway> factory = null;
		RetryScheduler retryScheduler = new IntervalRetryScheduler(scheduler, interval, retryCount);
		factory = new CommandGatewayFactoryBean<CommandGateway>();
		factory.setCommandBus(commandBus());
		factory.setRetryScheduler(retryScheduler);
		return factory;
	}

	/**
	 * It will automatically publish new events to the given EventBus and
	 * delegate event storage to the provided EventStore.
	 * 
	 * @return EventSourcingRepository
	 */
	@Bean
	EventSourcingRepository<CustomerAggregate> customerEventSourcingRepository() {
		EventSourcingRepository<CustomerAggregate> repo = new EventSourcingRepository<CustomerAggregate>(
				CustomerAggregate.class, eventStore());
		repo.setEventBus(eventBus());
		return repo;
	}

	/**
	 * This method registers your Aggregate Root as a @CommandHandler. Command
	 * handler that handles commands based on CommandHandler annotations on an
	 * aggregate.
	 * 
	 * @return AggregateAnnotationCommandHandler
	 */
	@Bean
	AggregateAnnotationCommandHandler<CustomerAggregate> customerAggregateCommandHandler() {
		return AggregateAnnotationCommandHandler.subscribe(CustomerAggregate.class, customerEventSourcingRepository(),
				commandBus());
	}

	/**
	 * Creating bean of commandservice.
	 * 
	 * @return Commandservice
	 */
	@Bean
	CommandService commandService() {
		return new CommandServiceImpl();
	}

}
