package com.barclayscard.customercommand.aggregate.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

import com.barclayscard.customer.valueobjects.Address;



/**
 * command class for updating address of customer.
 */
public class UpdateAddressCommand {

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final String id;

  /** Address [Building name, Street Name, Pin Code] of Customer. */
  @NotNull
  private final Address address;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier
   * @param address
   *          Address [Building name, Street Name, Pin Code]
   */
  public UpdateAddressCommand(String id, Address address) {
    super();
    this.id = id;
    this.address = address;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @return the address
   */
  public Address getAddress() {
    return address;
  }

}
