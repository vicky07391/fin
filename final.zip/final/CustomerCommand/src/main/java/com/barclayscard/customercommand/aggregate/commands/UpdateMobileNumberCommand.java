package com.barclayscard.customercommand.aggregate.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 * command class for updating mobile number of customer.
 */
public class UpdateMobileNumberCommand {

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final String id;

  /** Mobile Number. */
  @NotNull(message = "Mobile Number is mandatory")
  @NotBlank
  private final String mobileNumber;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier
   * @param mobileNumber
   *          Mobile Number
   */
  public UpdateMobileNumberCommand(String id, String mobileNumber) {
    this.id = id;
    this.mobileNumber = mobileNumber;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

}
