package com.barclayscard.customercommand.aggregate;

import org.axonframework.test.FixtureConfiguration;
import org.axonframework.test.Fixtures;
import org.junit.Before;

import com.barclayscard.customercommand.aggregate.commandhandler.UpdateEmailAddressCommandHandler;
/**
 *  test class for update email customer.
 * @author Capgemini.
 *
 */
public class UpdateEmailAddressCommandHandlerTest {
	/**
	 * fixtureConfiguration declared.
	 */
	private FixtureConfiguration<CustomerAggregate> fixture;
	/**
	 * Setup for Test cases.
	 * @throws Exception
	 *             Exception.
	 */

	@Before
	public void setUp() {
		fixture = Fixtures.newGivenWhenThenFixture(CustomerAggregate.class);
		UpdateEmailAddressCommandHandler commandHandler = new UpdateEmailAddressCommandHandler();
		fixture.registerAnnotatedCommandHandler(commandHandler);
		// commandHandler.setRepository(fixture.getRepository());
	}
	/**
	 * test case for update email address.
	 * @throws Exception Exception.
	 */
	/*@Test
	public void testUpdateEmailAddress() throws Exception {

		String oldEmailAddress = "prabhakar@capgemini.com";
		String newEmailAddress = "def@xyz.com";
		Address address = new Address("SunGreen Heights", "Woodcross Rod", "411038");

		fixture.given(new CustomerAddedEvent("e02bc32b-3aba-4701-b517-15325d4883bc",
				"Albert", "Piter", "9970685561",
				oldEmailAddress, address, new Date()))
				.when(new UpdateEmailAddressCommand("e02bc32b-3aba-4701-b517-15325d4883bc",
						newEmailAddress))
				.expectVoidReturnType()
				.expectEvents(new EmailAddressUpdatedEvent("e02bc32b-3aba-4701-b517-15325d4883bc",
						newEmailAddress));
	}*/
}
